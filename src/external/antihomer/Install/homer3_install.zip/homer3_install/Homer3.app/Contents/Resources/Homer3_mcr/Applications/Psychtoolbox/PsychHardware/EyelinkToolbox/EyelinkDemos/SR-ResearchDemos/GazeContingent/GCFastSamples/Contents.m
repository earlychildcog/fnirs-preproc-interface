% EyelinkToolbox:EyelinkDemos:SR-ResearchDemos:GazeContingent:EyeLink_GCFastSamples
% A simple EyeLink gaze-contingent demo showing how to retrieve fast online samples.
