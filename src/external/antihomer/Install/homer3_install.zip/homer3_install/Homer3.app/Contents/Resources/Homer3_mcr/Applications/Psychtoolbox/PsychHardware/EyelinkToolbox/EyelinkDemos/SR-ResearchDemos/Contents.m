% EyeLink systems allow for rich integration between a Display PC (the computer running Psychtoolbox) and the EyeLink Host PC via an ethernet connection using
% the EyeLink application programming interface (API). The API can be installed by downloading the EyeLink Developers Kit from our Support site:
