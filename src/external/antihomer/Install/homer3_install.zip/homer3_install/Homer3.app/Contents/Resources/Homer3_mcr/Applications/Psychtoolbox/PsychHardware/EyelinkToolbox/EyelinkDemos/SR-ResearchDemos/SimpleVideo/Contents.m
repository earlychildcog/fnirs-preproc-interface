% EyelinkToolbox:EyelinkDemos:SR-ResearchDemos:EyeLink_SimpleVideo
% Simple video demo with EyeLink integration and animated calibration / drift-check/correction targets.
