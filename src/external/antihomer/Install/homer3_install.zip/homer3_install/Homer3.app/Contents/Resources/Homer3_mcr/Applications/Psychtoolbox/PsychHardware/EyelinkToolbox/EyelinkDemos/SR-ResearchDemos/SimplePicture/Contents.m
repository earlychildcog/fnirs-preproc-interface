% EyelinkToolbox:EyelinkDemos:SR-ResearchDemos:SimplePicture
% Demo provided by SR-Research showing basic EyeLink
