% EyelinkToolbox:EyelinkBasic
% essential functions for use with the eyelinktoolbox
