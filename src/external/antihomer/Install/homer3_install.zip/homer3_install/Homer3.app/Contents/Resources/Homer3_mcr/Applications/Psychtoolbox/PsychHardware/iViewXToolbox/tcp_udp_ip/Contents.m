%TCP_UDP_IP  - Network comunication with other applic. & remote matlab control.
%
