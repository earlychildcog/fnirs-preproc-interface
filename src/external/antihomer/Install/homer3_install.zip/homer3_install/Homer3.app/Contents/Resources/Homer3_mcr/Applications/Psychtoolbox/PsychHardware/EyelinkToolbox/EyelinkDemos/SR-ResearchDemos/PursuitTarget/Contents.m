% EyelinkToolbox:EyelinkDemos:SR-ResearchDemos:EyeLink_PursuitTarget
% A smooth pursuit EyeLink integration demo that records eye movements
