% EyelinkToolbox:EyelinkDemos:SR-ResearchDemos:EyeLink_StereoPicture
% EyeLink integration demo for stereo presentation.
