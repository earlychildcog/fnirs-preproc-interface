% EyelinkToolbox:EyelinkDemos:SR-ResearchDemos:GazeContingent:GCBufferedEvents:EyeLink_BufferedEndSacEvents
% A simple EyeLink gaze-contingent demo showing how to retrieve online events from a buffer.
