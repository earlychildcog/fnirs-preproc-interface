% EyelinkToolbox:EyelinkDemos:SR-ResearchDemos:EyeLink_MRI_BlockRecord
% 6 trials are presented in 2 blocks of 3 trials. Trial duration is 5.5s during which a 4s stimulus is presented.
